import { Component } from "react";
import {connect} from 'react-redux';
import {deleteBlog} from './actions'
import {bindActionCreators} from "redux"
class DisplayBlog extends Component{
    constructor(props)
    {
        super(props)
    }
    render()
    {
     const element=<div>
         {
             this.props.blog.map((e)=>{
                 return <div>
                     <h3>{e.blogtitle}</h3>
                     <h2>{e.blogcontent}</h2>
                     <button onClick={(e1)=>{
                         this.props.dispatch(deleteBlog(e))
                     }}>Delete</button>
                     </div>
             })
         }
     </div>
 return element    
 // return <div></div>
}
}
function mapStateToProps(state)
{
    console.log("state "+state.blogReducer)
    return {
        blog:state.blogReducer
    }
}
export default (connect)(mapStateToProps)(DisplayBlog)  