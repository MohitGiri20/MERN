import { combineReducers } from "redux";
import blogReducer from "./blogReducer";
const blogitems=combineReducers({blogReducer})

export default blogitems