import * as myactions from '../actions/ActionType'
const blogReducer=(state=[],action)=>{
    switch(action.type){
        case myactions.ADD_BLOG:
            return state.concat([action.payload])
            //logic for . has to be written
        case myactions.UPDATE_BLOG:
         state=   state.map((e)=>{
                if(e.blogtitle===action.payload.blogtitle)
                {
                    e=action.payload
                }
           return e
            }
            )
             return state
         case myactions.DELETE_BLOG:
          return   state.filter((blog)=>blog.blogtitle!=action.payload.blogtitle)
                 
         default:
             return state        

    }
}

export default blogReducer