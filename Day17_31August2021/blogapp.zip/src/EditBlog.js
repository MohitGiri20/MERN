import { Component } from "react";
import {connect} from 'react-redux';
import { bindActionCreators } from "redux";
import { updateBlog } from "./actions";
 class EditBlogComponent extends Component{
    constructor(props)
    {
        super(props)
        this.state={
                blogtitle:"",
                blogcontent:""
        }
    }
    render()
    {
        const element=<center><div>
            Enter blog title to be edited<br/>
            <input type='text' onChange={(e)=>{
                this.setState({blogtitle:e.target.value})
            }}/><br/>
            Enter blog contents to be edited<br/>
            <textarea col="50" rows="10" onChange={(e)=>{
                this.setState({blogcontent:e.target.value})
            }}></textarea><br/>
            <button onClick={(e)=>{
                e.preventDefault();
                var blog={
                    blogtitle:this.state.blogtitle,
                    blogcontent:this.state.blogcontent
                }
                 this.props.dispatch(updateBlog(blog))
                //console.log(blog)
            }}>Edit Blog</button>

        </div>
        </center>
        return element
    }
}
function mapDispatchToProps(dispatch)
{
    return {action:bindActionCreators(updateBlog,dispatch)}
}
export default (connect)(mapDispatchToProps)(EditBlogComponent)