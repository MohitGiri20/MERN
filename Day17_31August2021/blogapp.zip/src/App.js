import logo from './logo.svg';
import './App.css';
import BlogComponent from './BlogComponent';
import DisplayBlog from './DisplayBlog';
import EditBlogComponent from './EditBlog';
import { Component } from 'react';
export default class App extends Component{
constructor(props)
{
super(props)
this.state={
  editstate:false
}
}
  render()
  {
    return (
      <div>
  {this.state.editstate?<EditBlogComponent />:<BlogComponent />}
  <button onClick={()=>{
  this.setState({editstate:!this.state.editstate})
  }}>Edit Blog</button>
  
  <DisplayBlog/>
      </div>
        );
  }
}
