import * as myactions from './ActionType'
export const addBlog=(blog)=>({

    type:myactions.ADD_BLOG,
    payload:blog

})
export const updateBlog=(blog)=>({
    type:myactions.UPDATE_BLOG,
    payload:blog
})
export const deleteBlog=(id)=>({
    type:myactions.DELETE_BLOG,
    payload:id
})