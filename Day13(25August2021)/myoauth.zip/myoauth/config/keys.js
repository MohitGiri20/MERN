
//insert own uri for database
//create own google api with client id and client secret for a different redirect url
module.exports = {
    google:{
        clientID:'639944755156-5svndklv21q00mplnoqj0ictmk729t95.apps.googleusercontent.com',
        clientSecret:"NHqdCdVdFyKFfhsbHb-_H4dg"
    },
    mongodb:{
        dbURI:"mongodb://localhost:27017/oauth"
    },
    session:{
        cookieKey:'tryingtodooauthihopeitworks'
    }, 
    
};